import logging
import tempfile
import snowflake.connector
from snowflake.connector.pandas_tools import write_pandas
import datetime
import requests
import os
import ast
import sys
from azure.keyvault.secrets import SecretClient
from azure.identity import AzureCliCredential, ManagedIdentityCredential
import base64
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (
    Mail, Attachment, FileContent, FileName,
    FileType, Disposition)
from io import BytesIO
import pandas as pd
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (Mail, Attachment, FileContent, FileName, FileType, Disposition)
from sendgrid.helpers.mail import Mail, Personalization, Bcc, To
from pretty_html_table import build_table

import azure.functions as func

errorlist = []

def send_email_with_csv(from_address, to_address, subject, content, dataframe, filename, filetype):
    
    
    message = Mail(
        from_email=from_address,
        to_emails=to_address,
        subject=subject,
        html_content=content)

    personalization = Personalization()
    for eachto in to_address:
        personalization.add_to(To(eachto))

    message.add_personalization(personalization)
    
    #%% Create buffered csv
    buffer = BytesIO()
    dataframe.to_excel(buffer, index=False);
    buffer.seek(0)
    data = buffer.read()
    encoded = base64.b64encode(data).decode()
    
    keyVaultName = os.environ["AzureAppKeyVaultName"]
    KVUri = f"https://{keyVaultName}.vault.azure.net"
    current_env = os.environ["StageName"]
    if current_env == "local":
        credential = AzureCliCredential()

    else:
        credential = ManagedIdentityCredential()
            
    client = SecretClient(vault_url=KVUri, credential=credential)
    sendgrid_api_key_1 = client.get_secret("sendgrid-token")
    sendgrid_api_key = sendgrid_api_key_1.value

    #%%
    attachment = Attachment()
    attachment.file_content = FileContent(encoded)
    attachment.file_type = FileType(filetype)
    attachment.file_name = FileName(filename)
    attachment.disposition = Disposition('attachment')
    message.attachment = attachment
    try:
        sendgrid_client = SendGridAPIClient(sendgrid_api_key)
        response = sendgrid_client.send(message)
        print(response.status_code)
        print(response.body)
        print(response.headers)
    except Exception as e:
        print(e.message)
        errorlist.append(e)

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    

    try:

        keyVaultName = os.environ["AzureAppKeyVaultName"]
        KVUri = f"https://{keyVaultName}.vault.azure.net"
        current_env = os.environ["StageName"]
        if current_env == "local":
            credential = AzureCliCredential()
            DATABASE = 'DEVELOPMENT'

        else:
            credential = ManagedIdentityCredential()
            DATABASE = current_env
        client = SecretClient(vault_url=KVUri, credential=credential)

        python_snowflake_uname = client.get_secret("python-env-sf-uname")
        python_snowflake_pass = client.get_secret("python-env-sf-password")

        tmp_path = tempfile.gettempdir()
        csv_path = os.path.join(tmp_path, "file.txt")

        SNOWFLAKE_USER = python_snowflake_uname.value
        SNOWFLAKE_PASSWORD = python_snowflake_pass.value
        SNOWFLAKE_ACCOUNT='wz65202.east-us-2.azure'
        SCHEMA = "EMAIL"
        TABLE = "daily_1315"

        myConnection = snowflake.connector.connect(
            user = SNOWFLAKE_USER,
            password = SNOWFLAKE_PASSWORD,
            account = SNOWFLAKE_ACCOUNT
            )
        cursor = myConnection.cursor()

        sql = "select * from " + DATABASE + "." + SCHEMA + "." + TABLE + ";"
        query_out = cursor.execute(sql)
        df = cursor.fetch_pandas_all()

        for ind in df.index:
            SUBJECT = df['SUBJECT'][ind]
            ATTACHMENTFILENAME_1 = df['ATTACHMENTFILENAME'][ind]
            STATEMENT = df['STATEMENT'][ind]
            TOEMAIL1 = df['TOEMAIL'][ind]
            BODY_MESSAGE = df['BODY_MESSAGE'][ind]
            FROM_EMAIL = df['FROM_EMAIL'][ind]
            CC_EMAIL = df['CC_EMAIL'][ind]

            email_query_result = cursor.execute(STATEMENT)

            ATTACHMENTFILENAME_1 = str(ATTACHMENTFILENAME_1) + " " + pd.Timestamp("today").strftime("%m-%d-%Y")
            ATTACHMENTFILENAME = ATTACHMENTFILENAME_1 + ".xlsx"
            #csv_path = os.path.join(tmp_path, ATTACHMENTFILENAME)

            #email_query_result.fetch_pandas_all().to_excel(csv_path)

            df_email_query_result = cursor.fetch_pandas_all()
            df_email_query_result = df_email_query_result.reset_index(drop=True)

            html_table_blue_light = build_table(df_email_query_result, 'blue_light')
            BODY_MESSAGE = BODY_MESSAGE + html_table_blue_light

            TOEMAIL = ast.literal_eval(TOEMAIL1)
            print("printing toemail " , TOEMAIL)

            #append current date
            SUBJECT = str(SUBJECT) + " " + pd.Timestamp("today").strftime("%m-%d-%Y")
            


            send_email_with_csv(from_address=FROM_EMAIL,
                    to_address=TOEMAIL,
                    subject=SUBJECT,
                    content=BODY_MESSAGE,
                    dataframe=df_email_query_result,
                    filename=ATTACHMENTFILENAME,
                    filetype='text/csv')
        
        myConnection.close()

        #query_out.fetch_pandas_all().to_csv("/path/to/write/table.csv") adding for demo

    except Exception as e1: 
        errorlist.append(e1)
                
    finally:

        if len(errorlist)==0:
            print("No error")
        else:
            t1 = "".join(str(element) for element in errorlist)
            d = {
            'ToEmail': 'prakharsingh.sengar@e-hps.com',
            'ccEMAIL': 'prakhar.sengar@heartland.us',
            'bodyEMAIL': t1,
            'subjecEMAIL': 'Please check email_monthly_python_1_0900'
            }
            r = requests.post('https://bedevappcustemailsg.azurewebsites.net/api/custom-email-sendgrid', json=d)
            print(r.status_code)
            print(r.headers)
            print(r.content)

    if name:
        return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
             status_code=200
        )
