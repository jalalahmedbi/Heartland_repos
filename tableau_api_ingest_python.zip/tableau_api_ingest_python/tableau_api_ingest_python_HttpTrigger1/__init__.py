import logging
import azure.functions as func
import pandas as pd
import snowflake.connector
import json
from sqlalchemy import create_engine
import requests
from requests.structures import CaseInsensitiveDict
import pandas as pd
import snowflake.connector
from snowflake.connector.pandas_tools import write_pandas
from datetime import datetime
from fastparquet import ParquetFile
from azure.keyvault.secrets import SecretClient
from azure.identity import AzureCliCredential, ManagedIdentityCredential
import snowflake.connector
from snowflake.connector.pandas_tools import write_pandas  
from pandas import json_normalize
from snowflake.connector.pandas_tools import pd_writer
import os,sys
from sqlalchemy import create_engine
import numpy as np
import snowflake.connector as sf
from datetime import datetime
import asyncio
from concurrent.futures import ThreadPoolExecutor
import concurrent.futures
from concurrent.futures import wait
import httpx
from itertools import chain
from multiprocessing import Pool
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, To, Cc, Bcc
import base64
import requests
from snowflake.connector import connect
from snowflake.connector import DictCursor
import shutil
import tableauserverclient as TSC
from sqlalchemy import create_engine

errorlist = []
keyVaultName = os.environ["AzureAppKeyVaultName"]
KVUri = f"https://{keyVaultName}.vault.azure.net"
# current_env = os.environ["StageName"]
# if current_env == "local":
#         credential = AzureCliCredential()
#         #schemavar = "TABLEAU_INTERNAL_PRD"
#         schemavar = "TABLEAU_PARTNER_PRD"
#         derivedschema = "TRANFORM_DEV"
#         branchvar = "dev"
# elif current_env == "DEVELOPMENT":
#         credential = ManagedIdentityCredential()
#         schemavar = "INGEST_DEV"
#         derivedschema = "TRANFORM_DEV"
#         branchvar = "dev"
# elif current_env == "BI":
#         credential = ManagedIdentityCredential()
#         schemavar = "INGEST_PRD"
#         derivedschema = "TRANFORM_PRD"
#         branchvar = "main"

def dynamic_global_variable(name, value):
     globals()[name] = value

global client
#client = SecretClient(vault_url=KVUri, credential=credential)
def remove_dirs(curr_dir='./', del_dirs=['temp_folder', '__pycache__']):
    for del_dir in del_dirs:
        if del_dir in os.listdir(curr_dir):
             shutil.rmtree(os.path.join(curr_dir, del_dir))
    for dir in os.listdir(curr_dir):
        dir = os.path.join(curr_dir, dir)
        if os.path.isdir(dir):
            remove_dirs.remove_dirs(dir, del_dirs)
remove_dirs
def df_to_snowflake(df, tablename):
    python_snowflake_uname = client.get_secret("python-env-sf-uname")
    python_snowflake_pass = client.get_secret("python-env-sf-password")
    account_identifier = 'wz65202.east-us-2.azure'
    user = python_snowflake_uname.value
    password = python_snowflake_pass.value
    database_name = 'BI_PLATFORM_METADATA'
    schema_name = schemavar
    conn_string = f"snowflake://{user}:{password}@{account_identifier}/{database_name}/{schema_name}"
    engine = create_engine(conn_string)
    connection = engine.connect()
    try:
        # with connection.cursor() as cursor:
        #     cursor.execute(f"USE DATABASE {snowflake_config['database']}")
        #     cursor.execute(f"USE SCHEMA {snowflake_config['schema']}")
        #     df.to_sql(name=tablename,
        #               con=connection,
        #               index=False,
        #               if_exists='replace')  
        df.to_sql(tablename, con=engine, index=False, if_exists='replace', method=pd_writer)
        print("Data inserted successfully into Snowflake!")
    except Exception as e:
        print("Error:", e)
    finally:
        connection.close()

async def populate_groups(server,user):
     groupn = server.users.populate_groups(user)
     group_names = [group.name for group in user.groups]
     return group_names

async def populate_users_in_group(server,group):
     usern = server.groups.populate_users(group)
     user_names = [group.name for group in group.users]
     return user_names

async def populate_connections_in_workbook(server,workbook):
     wkbkn = server.workbooks.populate_connections(workbook)
     connections = [[connection.datasource_id,connection.datasource_name,connection.connection_type,connection.username] for connection in workbook.connections]
     return connections

async def populate_views_in_workbook(server,workbook):
     wkbkn = server.workbooks.populate_views(workbook)
     views = [[view.content_url,view.name,view.id,view.owner_id] for view in workbook.views]
     return views

async def populate_connections_in_datasource(server,datasource):
     data_source = server.datasources.populate_connections(datasource)
     connections = [[connection.datasource_id,connection.datasource_name,connection.connection_type,connection.username] for connection in datasource.connections]
     return connections


def tableau_users_to_dataframe(server_url, token_name, personal_access_token, site=''):  
    tableau_auth = TSC.PersonalAccessTokenAuth(token_name=token_name, personal_access_token=personal_access_token, site_id=site)
    server = TSC.Server(server_url, use_server_version=True)
    data = []
    with server.auth.sign_in(tableau_auth):
        for user in TSC.Pager(server.users):
            user_id = user.id
            user_name = user.name
            user_fullname = user.fullname
            user_email = user.email
            user_last_login = user.last_login
            user_site_role = user.site_role
            coro = populate_groups(server,user)
            group_names1 = asyncio.run(coro)
            if 'BI_DEVELOPMENT' in group_names1:
                workbookn = server.users.populate_workbooks(user)
                workbook_names = [workbook.name for workbook in user.workbooks]
            else:
                workbook_names = None
        
            data.append([user_id, user_name, user_fullname, user_email, user_site_role, group_names1, workbook_names, user_last_login])
    
    df = pd.DataFrame(data, columns=['USER_ID', 'USERNAME', 'FULLNAME', 'EMAIL', 'SITE_ROLE', 'GROUP_NAMES', 'WORKBOOKS', 'LAST_LOGIN'])
    return df

def tableau_groups_to_dataframe(server_url, token_name, personal_access_token, site=''):  
    tableau_auth = TSC.PersonalAccessTokenAuth(token_name=token_name, personal_access_token=personal_access_token, site_id=site)
    server = TSC.Server(server_url, use_server_version=True)
    data = []
    with server.auth.sign_in(tableau_auth):
        for group in TSC.Pager(server.groups.get):
            group_id = group.id
            group_name = group.name
            coro1 = populate_users_in_group(server,group)
            user_names1 = asyncio.run(coro1)
           
            data.append([group_id, group_name, user_names1])
    
    df = pd.DataFrame(data, columns=['GROUP_ID', 'GROUP_NAME', 'MEMBERS'])
    return df

def tableau_workbooks_to_dataframe(server_url, token_name, personal_access_token, site=''):  
    tableau_auth = TSC.PersonalAccessTokenAuth(token_name=token_name, personal_access_token=personal_access_token, site_id=site)
    server = TSC.Server(server_url, use_server_version=True)
    data = []
    with server.auth.sign_in(tableau_auth):
        for workbook in TSC.Pager(server.workbooks.get):
            workbook_id = workbook.id
            workbook_name = workbook.name
            workbook_content_url = workbook.content_url
            workbook_created_at = workbook.created_at
            workbook_owner_id = workbook.owner_id
            workbook_project_id = str(workbook.project_id)
            workbook_project_name = workbook.project_name
            workbook_size = workbook.size
            workbook_show_tabs = workbook.show_tabs
            workbook_hidden_views = workbook.hidden_views
            workbook_tags = workbook.tags
            workbook_updated_at = workbook.updated_at
            workbook_webpage_url = workbook.webpage_url

            coro1 = populate_connections_in_workbook(server,workbook)
            workbook_connections = asyncio.run(coro1)

            coro2 = populate_views_in_workbook(server,workbook)
            workbook_views = asyncio.run(coro2)

           
            data.append([workbook_id, workbook_name, workbook_content_url,workbook_created_at,
                         workbook_owner_id,workbook_project_id,workbook_project_name,workbook_size,
                         workbook_show_tabs,workbook_hidden_views,workbook_tags,workbook_updated_at,
                         workbook_webpage_url,workbook_connections,workbook_views])
    
    df = pd.DataFrame(data, columns=['WORKBOOK_ID', 'WORKBOOK_NAME', 'WORKBOOK_CONTENT_URL','WORKBOOK_CREATED_AT',
                       'WORKBOOK_OWNER_ID','WORKBOOK_PROJECT_ID','WORKBOOK_PROJECT_NAME','WORKBOOK_SIZE',
                         'WORKBOOK_SHOW_TABS','WORKBOOK_HIDDEN_VIEWS','WORKBOOK_TAGS','WORKBOOK_UPDATED_AT',
                         'WORKBOOK_WEBPAGE_URL','WORKBOOK_CONNECTIONS','WORKBOOK_VIEWS'])
    return df

def tableau_views_to_dataframe(server_url, token_name, personal_access_token, site=''):  
    tableau_auth = TSC.PersonalAccessTokenAuth(token_name=token_name, personal_access_token=personal_access_token, site_id=site)
    server = TSC.Server(server_url, use_server_version=True)
    data = []
    with server.auth.sign_in(tableau_auth):
        all_views_1 =  list(TSC.Pager(server.views))
        total_views = len(all_views_1)
        page_count = total_views//999
        loop_count = page_count + 2
        logging.info('loop_count count is ' + str(loop_count))
        for i in range(1, loop_count):
            logging.info('currently processing ' + str(i))
            request_options = TSC.RequestOptions(pagenumber=i,pagesize=999)
                #for view in TSC.Pager(server.views):
            with server.auth.sign_in(tableau_auth):
                all_views, pagination_item = server.views.get(req_options=request_options, usage=True)
                for view in all_views:
                    view_id = view.id
                    logging.info('view_id is ' + view_id)
                    view_name = view.name
                    view_content_url = view.content_url
                    view_owner_id = view.owner_id
                    view_project_id = view.project_id
                    view_total_views = view.total_views
                    view_workbook_id = view.workbook_id
                    
                    data.append([view_id, view_name, view_content_url,view_owner_id,view_project_id,
                                    view_total_views,view_workbook_id])
    
    df = pd.DataFrame(data, columns=['VIEW_ID', 'VIEW_NAME', 'VIEW_CONTENT_URL','VIEW_OWNER_ID',
                                     'VIEW_PROJECT_ID', 'VIEW_TOTAL_VIEWS','VIEW_WORKBOOK_ID'])
    return df

def tableau_datasources_to_dataframe(server_url, token_name, personal_access_token, site=''):  
    tableau_auth = TSC.PersonalAccessTokenAuth(token_name=token_name, personal_access_token=personal_access_token, site_id=site)
    server = TSC.Server(server_url, use_server_version=True)
    data = []
    with server.auth.sign_in(tableau_auth):
        for datasource in TSC.Pager(server.datasources.get):
            datasource_id = datasource.id
            datasource_name = datasource.name
            datasource_content_url = datasource.content_url
            datasource_created_at = datasource.created_at
            datasource_owner_id = datasource.owner_id
            datasource_project_id = datasource.project_id
            datasource_project_name = datasource.project_name
            datasource_tags = datasource.tags
            datasource_updated_at = datasource.updated_at
            datasource_webpage_url = datasource.webpage_url

            coro1 = populate_connections_in_datasource(server,datasource)
            datasource_connections = asyncio.run(coro1)

            datasource_ask_data_enablement = datasource.ask_data_enablement
            datasource_certified = datasource.certified
            datasource_content_certification_note = datasource.certification_note
            datasource_created_datasource_type = datasource.datasource_type
            datasource_description = datasource.description
            datasource_project_encrypt_extracts = datasource.encrypt_extracts
            datasource_project_has_extracts = datasource.has_extracts
            datasource_use_remote_query_agent = datasource.use_remote_query_agent



           
            data.append([datasource_id, datasource_name, datasource_content_url,datasource_created_at,
                         datasource_owner_id,datasource_project_id,datasource_project_name
                        ,datasource_tags,datasource_updated_at,
                         datasource_webpage_url,datasource_connections,datasource_ask_data_enablement,
                         datasource_certified,datasource_content_certification_note,datasource_created_datasource_type,
                         datasource_description,datasource_project_encrypt_extracts,datasource_project_has_extracts,
                         datasource_use_remote_query_agent])
    
    df = pd.DataFrame(data, columns=['DATASOURCE_ID', 'DATASOURCE_NAME', 'DATASOURCE_CONTENT_URL','DATASOURCE_CREATED_AT',
                         'DATASOURCE_OWNER_ID','DATASOURCE_PROJECT_ID','DATASOURCE_PROJECT_NAME'
                        ,'DATASOURCE_TAGS','DATASOURCE_UPDATED_AT',
                         'DATASOURCE_WEBPAGE_URL','DATASOURCE_CONNECTIONS','DATASOURCE_ASK_DATA_ENABLEMENT',
                         'DATASOURCE_CERTIFIED','DATASOURCE_CONTENT_CERTIFICATION_NOTE','DATASOURCE_CREATED_DATASOURCE_TYPE',
                         'DATASOURCE_DESCRIPTION','DATASOURCE_PROJECT_ENCRYPT_EXTRACTS','DATASOURCE_PROJECT_HAS_EXTRACTS',
                         'DATASOURCE_USE_REMOTE_QUERY_AGENT'])
    return df

def tableau_schedules_to_dataframe(server_url, token_name, personal_access_token, site=''):  
    tableau_auth = TSC.PersonalAccessTokenAuth(token_name=token_name, personal_access_token=personal_access_token, site_id=site)
    server = TSC.Server(server_url, use_server_version=True)
    data = []
    with server.auth.sign_in(tableau_auth):
        for schedule in TSC.Pager(server.schedules.get):
            schedule_id = schedule.id
            schedule_name = schedule.name
            schedule_priority = schedule.priority
            schedule_schedule_type = schedule.schedule_type
            if schedule.ExecutionOrder.Parallel:
                schedule_execution_order = 'parallel'
            elif schedule.ExecutionOrder.Serial:
                schedule_execution_order = 'serial'
            #schedule_execution_order = schedule.execution_order
            # if  schedule.interval_item.HourlyInterval:
            #     schedule_interval_item = "HourlyInterval".lower()
            # if  schedule.IntervalIinterval_itemtem.DailyInterval:
            #     schedule_interval_item = "DailyInterval".lower()
            # if  schedule.interval_item.WeeklyInterval:
            #     schedule_interval_item = "WeeklyInterval".lower()
            # if  schedule.interval_item.MonthlyInterval:
            #     schedule_interval_item = "MonthlyInterval".lower()

            data.append([schedule_id,schedule_name, schedule_priority, schedule_schedule_type,
                         schedule_execution_order])
            
    
    df = pd.DataFrame(data, columns=['SCHEDULE_ID','SCHEDULE_NAME', 'SCHEDULE_PRIORITY', 'SCHEDULE_SCHEDULE_TYPE',
                         'SCHEDULE_EXECUTION_ORDER'])
    return df

def tableau_projects_to_dataframe(server_url, token_name, personal_access_token, site=''):  
    tableau_auth = TSC.PersonalAccessTokenAuth(token_name=token_name, personal_access_token=personal_access_token, site_id=site)
    server = TSC.Server(server_url, use_server_version=True)
    data = []
    with server.auth.sign_in(tableau_auth):
        for project in TSC.Pager(server.projects.get):
            project_name = project.name
            project_description = project.description
            project_project_id = project.id
            project_parent_id = project.parent_id
            project_content_permissions = project.content_permissions

            data.append([project_name, project_description, project_project_id,
                         project_parent_id,project_content_permissions])
            
    
    df = pd.DataFrame(data, columns=['PROJECT_NAME', 'PROJECT_DESCRIPTION', 'PROJECT_PROJECT_ID',
                         'PROJECT_PARENT_ID','PROJECT_CONTENT_PERMISSIONS'])
    return df

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    try:
        name = req.params.get('name')
        if not name:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                name = req_body.get('name')
        table_name = req.params.get('table_name')
        env = req.params.get('env')
        
        current_env = os.environ["StageName"]
        if current_env == "local":
                credential = AzureCliCredential()
            
                #schemavar = "TABLEAU_INTERNAL_PRD"
                #schemavar = "TABLEAU_PARTNER_PRD"
                #dynamic_global_variable(schemavar, "TABLEAU_PARTNER_PRD")
                kv_client = SecretClient(vault_url=KVUri, credential=credential)
                dynamic_global_variable("client", kv_client)
                
                
        elif current_env == "DEVELOPMENT":
                credential = ManagedIdentityCredential()
            
                kv_client = SecretClient(vault_url=KVUri, credential=credential)
                dynamic_global_variable("client", kv_client)
                
        elif current_env == "BI":
                credential = ManagedIdentityCredential()
            
                kv_client = SecretClient(vault_url=KVUri, credential=credential)
                dynamic_global_variable("client", kv_client)
                
        if str(env) == "internal":
            schemavar1 = "TABLEAU_INTERNAL_PRD"
            dynamic_global_variable("schemavar", schemavar1)
            tab_token_name_ = client.get_secret("tableau-internal-prd-token-name")
            tab_token_name = tab_token_name_.value
            tab_token_val_ = client.get_secret("tableau-internal-prd-token-value")
            tab_token_val = tab_token_val_.value
            
            if str(table_name) == "users":
                df1 = tableau_users_to_dataframe('https://tableau.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df1,tablename='users')
            elif str(table_name) == "groups":
                df2 = tableau_groups_to_dataframe('https://tableau.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df2,tablename='groups')
            elif str(table_name) == "workbooks":
                df3 = tableau_workbooks_to_dataframe('https://tableau.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df3,tablename='workbooks')
            elif str(table_name) == "views":
                df4 = tableau_views_to_dataframe('https://tableau.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df4,tablename='views')
            elif str(table_name) == "datasources":
                df5 = tableau_datasources_to_dataframe('https://tableau.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df5,tablename='datasources')
            elif str(table_name) == "schedules":
                df6 = tableau_schedules_to_dataframe('https://tableau.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df6,tablename='schedules')
            elif str(table_name) == "projects":
                df7 = tableau_projects_to_dataframe('https://tableau.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df7,tablename='projects')
            else:
                return  func.HttpResponse("Pass a name in the query string for a valid table_name")

        if str(env) == 'partner':
            schemavar1 = "TABLEAU_PARTNER_PRD"
            dynamic_global_variable("schemavar", schemavar1)
            tab_token_name_ = client.get_secret("tableau-pp-prd-token-name")
            tab_token_name = tab_token_name_.value
            tab_token_val_ = client.get_secret("tableau-pp-prd-token-value")
            tab_token_val = tab_token_val_.value

            if str(table_name) == "users":
                df1 = tableau_users_to_dataframe('https://partnertab.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df1,tablename='users')
            elif str(table_name) == "groups":
                df2 = tableau_groups_to_dataframe('https://partnertab.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df2,tablename='groups')
            elif str(table_name) == "workbooks":
                df3 = tableau_workbooks_to_dataframe('https://partnertab.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df3,tablename='workbooks')
            elif str(table_name) == "views":
                df4 = tableau_views_to_dataframe('https://partnertab.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df4,tablename='views')
            elif str(table_name) == "datasources":
                df5 = tableau_datasources_to_dataframe('https://partnertab.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df5,tablename='datasources')
            elif str(table_name) == "schedules":
                df6 = tableau_schedules_to_dataframe('https://partnertab.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df6,tablename='schedules')
            elif str(table_name) == "projects":
                df7 = tableau_projects_to_dataframe('https://partnertab.heartland.us', tab_token_name, tab_token_val)
                df_to_snowflake(df7,tablename='projects')
            else:
                return  func.HttpResponse("Pass a name in the query string for a valid environment")
        if name:
            return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
        else:
            return  func.HttpResponse(
                "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
                status_code=200
            )
    except Exception as e1: 
        errorlist.append(e1)
                
    finally:

        if len(errorlist)==0:
            print("No error")
        else:
            t1 = "".join(str(element) for element in errorlist)
            d = {
            'ToEmail': 'prakharsingh.sengar@e-hps.com',
            'ccEMAIL': 'prakhar.sengar@heartland.us',
            'bodyEMAIL': t1,
            'subjecEMAIL': 'Please check tableau_api_ingest_python'
            }
            r = requests.post('https://bedevappcustemailsg.azurewebsites.net/api/custom-email-sendgrid', json=d)
            print(r.status_code)
            print(r.headers)
            print(r.content)
