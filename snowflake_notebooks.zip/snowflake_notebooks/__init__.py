import azure.functions as func
import pandas as pd
import logging
from concurrent.futures import ThreadPoolExecutor
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from sqlalchemy import create_engine
from snowflake.connector.pandas_tools import pd_writer
import json
import aiohttp
from aiohttp_retry import RetryClient, ExponentialRetry
import asyncio
import os, sys
from azure.functions import HttpRequest, HttpResponse
from ratelimit import limits, sleep_and_retry
import snowflake.connector
from snowflake.sqlalchemy import URL
import gc
import requests
import time
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
from pandas import DataFrame
from pandas.io.sql import SQLTable

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

credential = DefaultAzureCredential()
keyVaultName = os.environ["AzureAppKeyVaultName"]
kv_uri = f"https://{keyVaultName}.vault.azure.net"
kv_client = SecretClient(vault_url=kv_uri, credential=credential)
current_env = os.environ["StageName"]

if current_env == "local":
    snowflake_schema = "HPOS_DEV_INGEST"
elif current_env == "DEVELOPMENT":
    snowflake_schema = "HPOS_DEV_INGEST"
else:
    snowflake_schema = "HPOS_PRD_INGEST"

def get_snowflake_credentials(kv_client):
    # Fetch the required secrets from Key Vault
    username = kv_client.get_secret("python-env-sf-uname").value
    passphrase = kv_client.get_secret("python-env-sf-passphrase").value
    private_key_pem = kv_client.get_secret("python-env-sf-private-key").value
    
    # Decode and load the private key
    passphrase_b = bytes(passphrase, encoding='utf-8')
    private_key_b = bytes(private_key_pem, encoding='utf-8')
    
    private_key = serialization.load_pem_private_key(
        private_key_b,
        password=passphrase_b,
        backend=default_backend()
    )
    
    private_key_der = private_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    
    return {
        "username": username,
        "private_key": private_key_der,
        "account": 'wz65202.east-us-2.azure',
        "database": 'ORDWAY',
        "warehouse": 'WH_ENGINEER',
        "schema": snowflake_schema
    }

def get_snowflake_engine(credentials):
    engine = create_engine(URL(
        account=credentials['account'],
        user=credentials['username'],
        database=credentials['database'],
        schema=credentials['schema'],
    ), connect_args={
        'private_key': credentials['private_key'],
    })
    return engine

def df_to_snowflake(kv_client, df, tablename):
    try:
        df = preprocess_data(df)  # Add this line to preprocess the DataFrame
        credentials = get_snowflake_credentials(kv_client)
        engine = get_snowflake_engine(credentials)
        df.columns = [col.upper() if not isinstance(col, int) else col for col in df.columns]
        df.to_sql(tablename, con=engine, index=False, if_exists='replace', method=pd_writer)
        logger.info(f"Data successfully appended into Snowflake for table {tablename}.")
    except Exception as e:
        logger.error(f"Error writing to Snowflake for table {tablename}: {e}")
        #raise

def preprocess_data(df):
    for column in df.columns:
        df[column] = df[column].replace('-', None)
        if df[column].dtype == 'object':
            try:
                df[column] = pd.to_numeric(df[column])
            except ValueError:
                pass
    return df

@sleep_and_retry
@limits(calls=10, period=1)
def fetch_page_sync(url, headers):
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            return response.json()
        return None
    except Exception as e:
        logger.error(f"Error fetching page {url}: {e}")
        return None

def fetch_all_pages_concurrently(headers, base_url, page_size=50, max_workers=9):
    all_data = []
    page_number = 1
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        while True:
            urls = [f"{base_url}?size={page_size}&page={page_number + i}" for i in range(max_workers)]
            future_to_url = {executor.submit(fetch_page_sync, url, headers): url for url in urls}
            for future in future_to_url:
                data = future.result()
                if data:
                    all_data.extend(data)
                else:
                    # If we receive no data for any page, we assume we've reached the end
                    return all_data
            page_number += max_workers
            # Respect rate limit
            time.sleep(1)
    return all_data

def flatten_data(data):
    df = pd.json_normalize(data, sep='_')
    for column in df.columns:
        if any(isinstance(x, list) for x in df[column].dropna()):
            df[column] = df[column].apply(lambda x: json.dumps(x) if isinstance(x, list) else x)
    return df

async def fetch_data_and_process(headers, base_url, page_size):
    try:
        logger.info(f"Fetching data from {base_url} with page size {page_size}")
        loop = asyncio.get_event_loop()
        raw_data = await loop.run_in_executor(None, fetch_all_pages_concurrently, headers, base_url, page_size)
        logger.info(f"Data fetched from {base_url}, processing data")
        with ThreadPoolExecutor() as executor:
            df = await loop.run_in_executor(executor, flatten_data, raw_data)
        logger.info(f"Data processed for {base_url}")
        return df
    except Exception as e:
        logger.error(f"Error fetching or processing data from {base_url}: {e}")
        #raise

async def fetch_multiple_endpoints(headers, base_urls):
    results = {}
    for key, url in base_urls.items():
        logger.info(f"Fetching data for {key} from {url}")
        df = await fetch_data_and_process(headers, url, page_size=50 if key != "revenue_schedules" else 500)
        results[key] = df
        start_time = time.time()
        df_to_snowflake(kv_client, df, key)
        end_time = time.time()
        duration = end_time - start_time
        email_body = f"Table: {key} loaded successfully. Time taken: {duration:.2f} seconds."
        email_subject = f"ORDWAY {key} Data Load Success"
        send_email_notification("diana.campbell@e-hps.com", "prakhar.sengar@heartland.us", email_subject, email_body)
        del df
        gc.collect()
    return results

def send_email_notification(to_email, cc_email, subject, body):
    try:
        payload = {
            'ToEmail': to_email,
            'ccEMAIL': cc_email,
            'bodyEMAIL': body,
            'subjecEMAIL': subject
        }
        response = requests.post('https://bedevappcustemailsg.azurewebsites.net/api/custom-email-sendgrid', json=payload)
        if response.status_code == 200:
            logger.info("Email notification sent successfully.")
        else:
            logger.error(f"Failed to send email notification. Status code: {response.status_code}")
    except Exception as e:
        logger.error(f"Error sending email notification: {e}")

async def main(req: HttpRequest) -> HttpResponse:
    errorlist = []
    instance = req.params.get('instance')
    table = req.params.get('table')

    if not instance or not table:
        return HttpResponse("Please pass both 'instance' and 'table' on the query string", status_code=400)

    headers = {
        'X-User-Company': 'Heartland POS',
        'X-User-Email': kv_client.get_secret("ordwayuseremail").value,
        'X-User-Token': kv_client.get_secret("ordwayusertoken").value,
        'X-API-KEY': kv_client.get_secret("ordwayapikey").value,
        'Content-Type': 'application/json'
    }

    schema = 'HPOS_DEV_INGEST' if current_env.lower() in ["local", "development"] else 'HPOS_PRD_INGEST'
    
    base_urls = {
        "billingrun": 'https://app.ordwaylabs.com/api/v1/billing_runs',
        "billingschedule": 'https://app.ordwaylabs.com/api/v1/billing_schedules',
        "customers": 'https://app.ordwaylabs.com/api/v1/customers',
        "invoices": 'https://app.ordwaylabs.com/api/v1/invoices',
        "orders": 'https://app.ordwaylabs.com/api/v1/orders',
        "payments": 'https://app.ordwaylabs.com/api/v1/payments',
        "products": 'https://app.ordwaylabs.com/api/v1/products',
        "subscriptions": 'https://app.ordwaylabs.com/api/v1/subscriptions',
        "chart_of_accounts": 'https://app.ordwaylabs.com/api/v1/chart_of_accounts',
        "revenue_schedules": 'https://app.ordwaylabs.com/api/v1/revenue_schedules'
    }

    try:
        if instance == "pos" and table == "fetch_multiple":
            results = await fetch_multiple_endpoints(headers, base_urls)
            return HttpResponse("Data successfully loaded into Snowflake.", status_code=200)
        
        elif instance == "pos" and table in base_urls:
            start_time = time.time()
            df = await fetch_data_and_process(headers, base_urls[table], page_size=50 if table != "revenue_schedules" else 500)
            if df.empty:
                return HttpResponse("No data available to load into Snowflake.", status_code=400)
            df_to_snowflake(kv_client, df, table)
            end_time = time.time()
            duration = end_time - start_time
            email_body = f"Table: {table} loaded successfully. Time taken: {duration:.2f} seconds."
            email_subject = f"ORDWAY {table} Data Load Success"
            send_email_notification("diana.campbell@e-hps.com", "prakhar.sengar@heartland.us", email_subject, email_body)
            del df
            gc.collect()
            return HttpResponse("Data successfully loaded into Snowflake.", status_code=200)
        
        else:
            return HttpResponse("Invalid parameters or access not configured for this instance or table", status_code=400)

    except Exception as e:
        logger.error(f"An error occurred: {e}")
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        logger.error(f"{exc_type} in {fname} at line {exc_tb.tb_lineno}")
        errorlist.append(str(e))
        errorlist.append(str(exc_type))
        errorlist.append(fname)
        errorlist.append(exc_tb.tb_lineno)

    finally:
        if len(errorlist) == 0:
            logger.info("No errors encountered")
        else:
            email_subject = f"ORDWAY Data Load Failure"
            email_body = "".join(str(element) for element in errorlist)
            send_email_notification("diana.campbell@e-hps.com", "prakhar.sengar@heartland.us", email_subject, email_body)
            return HttpResponse(str(e), status_code=500)
        gc.collect()
