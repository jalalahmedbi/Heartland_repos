#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__author__ = "Dany Davila"
__version__ = "1.0.0"
__license__ = ""

import time
import random
import json
import requests
from urllib.parse import urlparse, parse_qs
from datetime import datetime, timedelta
from parseurl import ParseURL
from pprint import pprint
from iohelper import parse_browser_agent, parse_client_request_query_string, merge_two_dicts, \
	parse_client_referer_url_string

# the endpoint of GraphQL API
url = 'https://api.cloudflare.com/client/v4/graphql/'

# Customize these variables.
file_dir = ''  # Must include trailing slash. If left blank,
# csv will be created in the current directory.
api_token = 'rGN0cLBPhovBHELPlnF5e9UcFxSNv3vOEdEqv0_q'
api_account = '87f0653aa22d1b9069f37eb695320703'
# Set most recent day as yesterday by default.
offset_days = 1
# How many days worth of data do we want? By default, 7.
historical_days = 1
url_parser = ParseURL()


def get_past_date(num_days):
	today = datetime.utcnow().date()
	return today - timedelta(days=num_days)


def get_cf_graphql(limit, start_date, end_date):
	assert (start_date <= end_date)
	headers = {
		'Content-Type': 'application/json',
		'Authorization': f'Bearer {api_token}'
	}
	# The GQL query we would like to use:
	#  action": "block"
	payload = f'''{{
    "query": "query ActivityLogQuery($zoneTag: string, $filter: FirewallEventsAdaptiveGroupsFilter_InputObject, $activityFilter: FirewallEventsAdaptiveFilter_InputObject, $limit: int64!) {{  viewer {{    scope: zones(filter: {{zoneTag: $zoneTag}}) {{      activity: firewallEventsAdaptive(filter: $activityFilter, limit: $limit, orderBy: [datetime_DESC, rayName_DESC, matchIndex_ASC]) {{        action        apiGatewayMatchedEndpoint        clientAsn        clientCountryName        clientIP        clientIPClass        clientRefererHost        clientRefererPath        clientRefererQuery        clientRequestHTTPHost        clientRequestHTTPMethodName        clientRequestHTTPProtocol        clientRequestPath        clientRequestQuery        clientRequestScheme        contentScanHasFailed        contentScanObjResults        datetime        edgeResponseStatus        httpApplicationVersion        matchIndex        originResponseStatus        rayName        ruleId        rulesetId        sampleInterval        source        userAgent        wafAttackScore        wafAttackScoreClass        wafRceAttackScore        wafXssAttackScore        __typename      }}      __typename    }}    __typename  }}}}",
    "variables": {{
      "accountTag": "fdd8378f5b1a64768dedc1b66c0fd1da",
      "zoneTag": "87f0653aa22d1b9069f37eb695320703",
      "limit": {limit},
      "activityFilter": {{
        "AND": [
          {{
            "datetime_geq": "{start_date}",
            "datetime_leq": "{end_date}"
          }},
      {{
        "clientCountryName": "US"
      }},
      {{
        "userAgent_neq": ""
      }},
      {{
        "userAgent_neq": "test"
      }},
      {{
        "userAgent_notlike": "%curl%"
      }},
      {{
        "userAgent_notlike": "%Go-http-client%"
      }},
      {{
        "userAgent_notlike": "%Python%"
      }},
      {{
        "userAgent_notlike": "%python-requests%"
      }},
      {{
        "userAgent_notlike": "%urllib%"
      }},
      {{
        "clientRequestPath_neq": "/.well-known/assetlinks.json"
      }},
      {{
        "clientRequestHTTPHost_neq": "www.heartland.us:443"
      }},
          {{
            "AND": [
              {{
                "action_neq": "challenge_solved"
              }},
              {{
                "action_neq": "challenge_failed"
              }},
              {{
                "action_neq": "challenge_bypassed"
              }},
              {{
                "action_neq": "jschallenge_solved"
              }},
              {{
                "action_neq": "jschallenge_failed"
              }},
              {{
                "action_neq": "jschallenge_bypassed"
              }},
              {{
                "action_neq": "managed_challenge_skipped"
              }},
              {{
                "action_neq": "managed_challenge_non_interactive_solved"
              }},
              {{
                "action_neq": "managed_challenge_interactive_solved"
              }},
              {{
                "action_neq": "managed_challenge_bypassed"
              }},
              {{
                "action_neq": "managed_challenge_failed"
              }},
              {{
                "OR": [
                  {{
                    "ruleId_like": "999___"
                  }},
                  {{
                    "ruleId_like": "900___"
                  }},
                  {{
                    "ruleId": "981176"
                  }},
                  {{
                    "AND": [
                      {{
                        "ruleId_notlike": "9_____"
                      }},
                      {{
                        "ruleId_notlike": "uri-9_____"
                      }}
                    ]
                  }}
                ]
              }}
            ]
          }}
        ]
      }}
    }}
  }}'''

	r = requests.post(url, data=payload.replace('\n', ''), headers=headers, verify=False)
	return r


def process_request_data(raw_data):
  item_data_list=[]
	# raw data is a json string convert to dict'
  data = json.loads(raw_data)["data"]
  errors = json.loads(raw_data)['errors']

  pprint(errors)
  # Check if we got any errors
  if not "viewer" in data or not 'scope' in data['viewer']:
    print('Failed to retrieve data: GraphQL API responded with error:')
    # print(raw_data)
    return

  # pprint(data)
  # loop through the raw_data['viewer']['scope']['activity'] and print it

  for item in data['viewer']['scope'][0]['activity']:
    # client request query dicts
    client_request_utm_dict = parse_client_request_query_string(item['clientRequestQuery'])
    item_data = merge_two_dicts(item, client_request_utm_dict)

    # user agent dicts
    parsed_user_agent = parse_browser_agent(item_data['userAgent'])
    item_data = merge_two_dicts(item_data, parsed_user_agent)

    # referer dicts
    parsed_referer = parse_client_referer_url_string(item['clientRefererQuery'])
    item_data = merge_two_dicts(item_data, parsed_referer)

    parsed_user_agent = parse_browser_agent(item['userAgent'])
    item_data = merge_two_dicts(item_data, parsed_user_agent)
    batch_info = {
      'log_pull_batch_name': "2023-07-17-LOG13",
      'log_pull_batch_datetime': datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    item_data = merge_two_dicts(item_data, batch_info)
    # send to a database
    # pprint(item_data)
    item_data_list.append(item_data)
  return item_data_list

import snowflake.connector
def snowflake_connection():
  conn = snowflake.connector.connect (user='svc_python_dev',
  password='yCYWNkR&C6q6Hzy',
  account='wz65202.east-us-2.azure',
  warehouse='WH_ADHOC',
  database= 'DEVELOPMENT',
  schema='MARKETING',
  role='SVC_ENGINEER_DEV')
  return conn


def snowflake_insert(connection, traffic_data_list):
  table_name='TEMP_CLOUDFLARE_EVENTS_DATA'
  columns = ', '.join(traffic_data_list[0].keys())
  values= ', '.join(["%({})s".format(k) for k in traffic_data_list[0].keys()])
  sql = "insert into {} ({}) values ({})".format(table_name, columns,values)

  with connection.cursor() as cursor:
    cursor.executemany(sql, traffic_data_list)
    connection.commit()
    print('records inserted into temp table')
def snowflake_create_table(connection):#we are dropping and cloning the target table so we can then just delete the necessary incremental data and then insert.
  sql_drop = "drop table if exists DEVELOPMENT.MARKETING.TEMP_CLOUDFLARE_EVENTS_DATA;"
  sql_create_table = """create table DEVELOPMENT.MARKETING.TEMP_CLOUDFLARE_EVENTS_DATA
  clone  DEVELOPMENT.MARKETING.CLOUDFLARE_EVENTS_DATA copy grants;"""
  with connection.cursor() as cursor:
    cursor.execute(sql_drop)
    connection.commit()
    print('temp table dropped')
    cursor.execute(sql_create_table)
    connection.commit()
    print('temp table re-created')

def snowflake_delete(connection, delete_after_date):
  sql_delete_records = """delete from DEVELOPMENT.MARKETING.TEMP_CLOUDFLARE_EVENTS_DATA where datetime>='{}'""".format(delete_after_date)
  print('sql_delete_records : ', sql_delete_records)
  with connection.cursor() as cursor:
    cursor.execute(sql_delete_records)
    connection.commit()
    print('record deleted from temp table')

def snowflake_swap(connection):
  sql_swap="""ALTER TABLE DEVELOPMENT.MARKETING.TEMP_CLOUDFLARE_EVENTS_DATA SWAP WITH DEVELOPMENT.MARKETING.CLOUDFLARE_EVENTS_DATA;"""
  print('sql_swap : ', sql_swap)
  with connection.cursor() as cursor:
    cursor.execute(sql_swap)
    connection.commit()
    print('temp and target switched')

def main():
  """ Main entry point of the app """

  global item_end_date
  counter = 1
  api_row_limit = 10000
  

  current_datetime = datetime.utcnow() #utc because the datetime field coming from cloudflare is also UTC
  minus_1_day=current_datetime - timedelta(days=1)#I figure we will re-pull and delete 1 days worth of data for every run.
  formatted_current_datetime=current_datetime.strftime("%Y-%m-%dT%H:%M:%SZ")
  formatted_minus_1_day=minus_1_day.strftime("%Y-%m-%dT%H:%M:%SZ")
  start_date_obj=formatted_minus_1_day
  

  snowflake_create_table(snowflake_connection())#drop temp table, re-create temp table by cloning target table
  snowflake_delete(snowflake_connection(), start_date_obj)#delete all records that are after my new data start time. This looks at event data not etl data for the delete
  end_date_timestamp=current_datetime
  combined_events_data=[]

  #we have to pull the data in 6 hour windows due to api restrictions. 
  # So we are choosing a new start and end date until we satisfy the run.
  while True:
    if counter == 1:
      start_date = minus_1_day
    else:
      start_date = item_end_date#if not the first loop, then start where the previous loop left off

    item_start_date = start_date
    item_start_date_string = item_start_date.strftime("%Y-%m-%dT%H:%M:%SZ")
    item_end_date = item_start_date + timedelta(hours=6)#6 hour restriction shared by Danny Davila
    item_end_date_string = item_end_date.strftime("%Y-%m-%dT%H:%M:%SZ")

    #break if we have covered all the time segments
    if item_start_date > end_date_timestamp:
      print("End of the loop")
      break

    req = get_cf_graphql(api_row_limit, item_start_date_string, item_end_date_string) #this pulls the actual data from cloudflare
    if req.status_code == 200:
      events_data=process_request_data(req.text)
      for td in events_data:
        combined_events_data.append(td)#adding every record to a larger dataset since we cannot process a full days worth of data at a time
    else:
      print("Failed to retrieve data: GraphQL API responded with {} status code".format(req.status_code))

    # increment the file number
    counter += 1
    
    
    

    sleep_time = random.randint(1, 10)#Danny had this in here, I am guessing the api was shutting us down so doing random.
    print("[Slow the process ] Sleeping for " + str(sleep_time) + " seconds")
    time.sleep(sleep_time)
  start_index=0
  #was getting error from snowflake when trying to insert more than 10k at a time, so set up process to load 10k at a time until done
  if len(combined_events_data)>10000: 
    end_index=10000
  else:
    end_index=len(combined_events_data)
  while end_index<=len(combined_events_data):
    snowflake_insert(snowflake_connection(),combined_events_data[start_index:end_index])
    start_index=end_index#placing start at the end to get next batch
    if end_index==len(combined_events_data):#this will kill loop
      end_index=end_index+10000
    elif end_index + 10000 <= len(combined_events_data):#this will process a new batch
      end_index=end_index+10000
    elif end_index+10000>len(combined_events_data):#this takes us to the end of the dataset
      end_index=len(combined_events_data)
  snowflake_swap(snowflake_connection())#swaping temp and target table


# Prevents main() from being executed during imports.
if __name__ == "__main__":
	""" This is executed when run from the command line """
	main()
