from api_pull_events import main as main_events 
from api_pull_traffics import main as main_traffics

main_events()
main_traffics()

