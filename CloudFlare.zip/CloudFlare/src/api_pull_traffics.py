#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__author__ = "Dany Davila"
__version__ = "1.0.0"
__license__ = ""

import time
import random
import json
import requests
from datetime import datetime, timedelta
from iohelper import parse_client_referer_url_string, parse_client_request_query_string, \
	parse_browser_agent,merge_two_dicts
from pprint import pprint

# the endpoint of GraphQL API
url = 'https://api.cloudflare.com/client/v4/graphql/'

api_token = 'rGN0cLBPhovBHELPlnF5e9UcFxSNv3vOEdEqv0_q'
api_account = '87f0653aa22d1b9069f37eb695320703'


def get_past_date(num_days):
	today = datetime.utcnow().date()
	return today - timedelta(days=num_days)


def get_cf_graphql(limit, start_date, end_date):
	assert (start_date <= end_date)
	headers = {
		'Content-Type': 'application/json',
		'Authorization': f'Bearer {api_token}'
	}
	# The GQL query we would like to use:
	#  action": "block"
	payload = f'''{{
    "query": "query ZapTimeseriesBydatetimeGroupedByclientRequestPath( $zoneTag: string $filter: ZoneHttpRequestsAdaptiveGroupsFilter_InputObject ) {{ viewer {{ zones(filter: {{ zoneTag: $zoneTag }}) {{ series: httpRequestsAdaptiveGroups(limit: 10000, filter: $filter) {{ count avg {{ sampleInterval __typename }} sum {{ edgeResponseBytes visits __typename }} dimensions {{ botManagementDecision: botManagementDecision botScoreSrcName: botScoreSrcName clientAsn: clientAsn clientASNDescription: clientASNDescription clientCountryName: clientCountryName clientIP: clientIP clientRefererHost: clientRefererHost clientRequestHTTPHost: clientRequestHTTPHost clientRequestHTTPMethodName: clientRequestHTTPMethodName clientRequestPath: clientRequestPath clientRequestQuery: clientRequestQuery clientRequestReferer: clientRequestReferer datetime: datetime edgeResponseContentTypeName: edgeResponseContentTypeName edgeResponseStatus: edgeResponseStatus originIP: originIP originResponseStatus: originResponseStatus sampleInterval: sampleInterval securityAction: securityAction securitySource: securitySource userAgent: userAgent wafAttackScore: wafAttackScore wafAttackScoreClass: wafAttackScoreClass wafXssAttackScore: wafXssAttackScore xRequestedWith: xRequestedWith }} __typename }} __typename }} __typename }} }}",
     "variables": {{
    "accountTag": "fdd8378f5b1a64768dedc1b66c0fd1da",
    "zoneTag": "87f0653aa22d1b9069f37eb695320703",
    "filter": {{
      "AND": [
        {{
            "datetime_geq": "{start_date}",
            "datetime_leq": "{end_date}"
        }},
        {{
          "userAgent_neq": "Site24x7"
        }},
        {{
          "userAgent_notlike": "%Freshping%"
        }},
        {{
          "userAgent_notlike": "%Uptime%"
        }},
        {{
          "userAgent_notlike": "%Pingdom%"
        }},
        {{
          "clientRequestHTTPHost": "www.heartland.us"
        }},
        {{
             "userAgent_neq": ""
         }},
        {{
         "userAgent_neq": "test"
        }},
        {{
          "clientRequestPath_notlike": "%/.well-known/%"
        }},
        {{
         "clientRequestPath_neq": "//.well-known/"
        }},
      {{
        "userAgent_notlike": "%wget%"
      }},
      {{
        "userAgent_notlike": "%Java%"
      }},
      {{
        "userAgent_notlike": "%curl%"
      }},
      {{
        "userAgent_notlike": "%Python%"
      }},
      {{
        "userAgent_notlike": "%Python-urllib%"
      }},
      {{
        "userAgent_notlike": "%python-requests%"
      }},
      {{
        "userAgent_notlike": "%urllib%"
      }},
       {{
        "userAgent_notlike": "%PHP%"
      }},
      {{
        "userAgent_notlike": "%PycURL%"
      }},
       {{
        "userAgent_notlike": "%GuzzleHttp%"
      }},
     {{
        "userAgent_notlike": "%Go-http%"
      }},
       {{
        "clientRequestPath_notlike": "/favicon.ico"
      }},
      {{
          "clientRequestPath_notlike": "%/layouts/system%"
        }},
        {{
          "clientRequestPath_notlike": "%/sxa/%"
        }},
        {{
          "clientRequestPath_notlike": "%.ico%"
        }},
        {{
          "clientRequestPath_notlike": "%.pdf%"
        }},
        {{
          "clientRequestPath_notlike": "%.php%"
        }},
        {{
          "clientRequestPath_notlike": "%.png%"
        }},
        {{
          "clientRequestPath_notlike": "%.js%"
        }},
        {{
          "clientRequestPath_notlike": "%.jpg%"
        }},
        {{
          "clientRequestPath_notlike": "%.gif%"
        }},
        {{
          "clientRequestPath_notlike": "%.asp%"
        }},
        {{
          "clientRequestPath_notlike": "%wlwmanifest%"
        }},
        {{
          "clientRequestPath_notlike": "%.git%"
        }},
        {{
          "clientRequestPath_notlike": "%/durbin%"
        }},
        {{
          "clientRequestPath_notlike": "%/xmlrpc.php%"
        }},
        {{
          "clientRequestPath_notlike": "%/Blueprint.aspx%"
        }},
        {{
          "clientRequestPath_notlike": "%.jsp%"
        }},
        {{
          "clientRequestPath_notlike": "%/.aws%"
        }},
        {{
          "clientRequestPath_notlike": "%/.env%"
        }},
        {{
          "clientRequestPath_notlike": "%/index.php%"
        }},
        {{
          "clientRequestPath_notlike": "%/wp-includes%"
        }},
        {{
          "clientRequestPath_notlike": "%/wp-content/%"
        }},
        {{
          "clientRequestPath_notlike": "%/wp/%"
        }}
      ]
    }}
  }}
  }}'''
	payload = payload.replace('\n', '')
	payload = " ".join(payload.split())
	# print( payload )
	r = requests.post(url, data=payload.replace('\n', ''), headers=headers, verify=False)
	return r


def process_request_data(raw_data, batch_name: str = None):
  item_data_list=[]
  data = json.loads(raw_data)["data"]
  errors = json.loads(raw_data)['errors']
  

  if not "viewer" in data or not 'zones' in data['viewer']:
    print('Failed to retrieve data: GraphQL API responded with error:')
    # print(raw_data)
    pprint(errors)
    return

  for item in data['viewer']['zones'][0]['series']:
    item_data = item['dimensions']
    # print('##################################### item',item)
    # Keys 'botManagementDecision'
    # 'botScoreSrcName'
    # 'clientASNDescription'
    # 'clientAsn'
    # 'clientCountryName'
    # 'clientIP'
    # 'clientRefererHost'
    # 'clientRequestHTTPHost'
    # 'clientRequestHTTPMethodName'
    # 'clientRequestPath'
    # 'clientRequestQuery'
    # 'clientRequestReferer'
    # 'datetime'
    # 'edgeResponseContentTypeName'
    # 'edgeResponseStatus'
    # 'originIP'
    # 'originResponseStatus'
    # 'sampleInterval'
    # 'securityAction'
    # 'securitySource'
    # 'userAgent'
    # 'wafAttackScore'
    # 'wafAttackScoreClass'
    # 'wafXssAttackScore'
    # 'xRequestedWith': ''

    # client request query dicts
    client_request_utm_dict = parse_client_request_query_string(item_data['clientRequestQuery'])
    item_data = merge_two_dicts(item_data, client_request_utm_dict)
    
    # print('##################################### item_data1',item_data)
    # Keys added: 'clientRequest_utm_source'
    # 'clientRequest_utm_medium'
    # 'clientRequest_utm_campaign'
    # 'clientRequest_utm_content'
    # 'clientRequest_utm_term'
    # 'clientRequest_product'
    # 'clientRequest_search_keyword'
    # 'clientRequest_msclkid'
    # 'clientRequest_gclid'
    

    # user agent dicts
    parsed_user_agent = parse_browser_agent(item_data['userAgent'])
    item_data = merge_two_dicts(item_data, parsed_user_agent)
    # print('##################################### item_data2',item_data)
    #Keys added: 'user_agent_device_family'
    # 'user_agent_device_brand'
    # 'user_agent_device_model'
    # 'user_agent_platform_family'
    # 'user_agent_platform_major'
    # 'user_agent_platform_minor'
    # 'user_agent_platform_patch'
    # 'user_agent_family'
    # 'user_agent_major'
    # 'user_agent_minor'
    # 'user_agent_patch'

    # referer dicts
    parsed_referer = parse_client_referer_url_string(item_data['clientRequestReferer'])
    item_data = merge_two_dicts(item_data, parsed_referer)
    # print('##################################### item_data3',item_data)
    #Keys added: 'clientRefererScheme'
    # 'clientRefererPath'
    # 'clientRefererQuery'
    # 'clientReferer_utm_source'
    # 'clientReferer_utm_medium'
    # 'clientReferer_utm_campaign'
    # 'clientReferer_utm_content'
    # 'clientReferer_utm_term'
    # 'clientReferer_product'
    # 'clientReferer_search_keyword'
    # 'clientReferer_msclkid'
    # 'clientReferer_gclid': ''
    
    # normalize the country name
    item_data['clientRequest_CountryCode'] = item_data['clientCountryName']
    # print('##################################### item_data4',item_data)

    batch_info = {
      'log_pull_batch_name': batch_name,
      'log_pull_batch_datetime': datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
      # "typename": item_data['__typename'],
      'count': item['count'],
      'avg_typename': item['avg']['__typename'],
      'avg_sampleInterval': item['avg']['sampleInterval'],
      'sum_edgeResponseBytes': item['sum']['edgeResponseBytes'],
      'sum_visits': item['sum']['visits'],
      'sum_typename': item['sum']['__typename'],
      "accountTag": "fdd8378f5b1a64768dedc1b66c0fd1da",
      "zoneTag": "87f0653aa22d1b9069f37eb695320703",
    }
    item_data = merge_two_dicts(item_data, batch_info)
    # print('##################################### item_data5',item_data)
    # send to a database
    # print('item_data', item_data)
    item_data_list.append(item_data)
  return item_data_list

import snowflake.connector
def snowflake_connection():
  conn = snowflake.connector.connect (user='svc_python_dev',
  password='yCYWNkR&C6q6Hzy',
  account='wz65202.east-us-2.azure',
  warehouse='WH_ADHOC',
  database= 'DEVELOPMENT',
  schema='MARKETING',
  role='SVC_ENGINEER_DEV')
  return conn


def snowflake_insert(connection, traffic_data_list):
  table_name='TEMP_CLOUDFLARE_TRAFFIC_DATA'
  columns = ', '.join(traffic_data_list[0].keys())
  values= ', '.join(["%({})s".format(k) for k in traffic_data_list[0].keys()])
  sql = "insert into {} ({}) values ({})".format(table_name, columns,values)

  with connection.cursor() as cursor:
    cursor.executemany(sql, traffic_data_list)
    connection.commit()
    print('records inserted into temp table')
def snowflake_create_table(connection):#we are dropping and cloning the target table so we can then just delete the necessary incremental data and then insert.
  sql_drop = "drop table if exists DEVELOPMENT.MARKETING.TEMP_CLOUDFLARE_TRAFFIC_DATA;"
  sql_create_table = """create table DEVELOPMENT.MARKETING.TEMP_CLOUDFLARE_TRAFFIC_DATA
  clone  DEVELOPMENT.MARKETING.CLOUDFLARE_TRAFFIC_DATA copy grants;"""
  with connection.cursor() as cursor:
    cursor.execute(sql_drop)
    connection.commit()
    print('temp table dropped')
    cursor.execute(sql_create_table)
    connection.commit()
    print('temp table re-created')

def snowflake_delete(connection, delete_after_date):
  sql_delete_records = """delete from DEVELOPMENT.MARKETING.TEMP_CLOUDFLARE_TRAFFIC_DATA where datetime>='{}'""".format(delete_after_date)
  print('sql_delete_records : ', sql_delete_records)
  with connection.cursor() as cursor:
    cursor.execute(sql_delete_records)
    connection.commit()
    print('record deleted from temp table')

def snowflake_swap(connection):
  sql_swap="""ALTER TABLE DEVELOPMENT.MARKETING.TEMP_CLOUDFLARE_TRAFFIC_DATA SWAP WITH DEVELOPMENT.MARKETING.CLOUDFLARE_TRAFFIC_DATA;"""
  print('sql_swap : ', sql_swap)
  with connection.cursor() as cursor:
    cursor.execute(sql_swap)
    connection.commit()
    print('temp and target switched')


def main():
  global item_end_date 
  batch_name="2023-05-20-LOG27"
  counter = 1
  api_row_limit = 10000
  
  
  # current_datetime = datetime.today()# - timedelta(days=1)
  current_datetime = datetime.utcnow()
  minus_1_day=current_datetime - timedelta(days=2)
  formatted_current_datetime=current_datetime.strftime("%Y-%m-%dT%H:%M:%SZ")
  formatted_minus_1_day=minus_1_day.strftime("%Y-%m-%dT%H:%M:%SZ")
  start_date_obj=formatted_minus_1_day
  end_date_obj=formatted_current_datetime
  
  print('timesssssssss', start_date_obj, end_date_obj)
  

  #prep the data for the inserts
  snowflake_create_table(snowflake_connection())
  snowflake_delete(snowflake_connection(), start_date_obj)
  end_date_timestamp=current_datetime
  combined_traffic_data=[]
  while True:
    if counter == 1:
      start_date = minus_1_day
    else:
      start_date = item_end_date

    
    item_start_date = start_date
    item_start_date_string = item_start_date.strftime("%Y-%m-%dT%H:%M:%SZ")
    item_end_date = item_start_date + timedelta(hours=6)
    item_end_date_string = item_end_date.strftime("%Y-%m-%dT%H:%M:%SZ")

    

    req = get_cf_graphql(api_row_limit, item_start_date_string, item_end_date_string)
    if req.status_code == 200:
      traffic_data=process_request_data(req.text, batch_name)
      for td in traffic_data:
        combined_traffic_data.append(td)
    else:
      print("Failed to retrieve data: GraphQL API responded with {} status code".format(req.status_code))

    # increment the file number
    counter += 1
    print("[tem_counter ] {}".format(counter))
    # convert the start date to unix time
    current_item_date_timestamp = item_start_date.timestamp()
    # if current_item_date_timestamp > end_date_timestamp:
    if item_start_date > end_date_timestamp:
      print("End of the loop")
      break

    sleep_time = random.randint(1, 10)
    print("[Slow the process ] Sleeping for " + str(sleep_time) + " seconds")
    time.sleep(sleep_time)
  start_index=0
  if len(combined_traffic_data)>10000:
    end_index=10000
  else:
    end_index=len(combined_traffic_data)
  while end_index<=len(combined_traffic_data):
    snowflake_insert(snowflake_connection(),combined_traffic_data[start_index:end_index])
    start_index=end_index
    if end_index==len(combined_traffic_data):
      end_index=end_index+10000
    elif end_index + 10000 <= len(combined_traffic_data):
      end_index=end_index+10000
    elif end_index+10000>len(combined_traffic_data):
      end_index=len(combined_traffic_data)
  snowflake_swap(snowflake_connection())
  return combined_traffic_data





# Prevents main() from being executed during imports.
if __name__ == "__main__":
	""" This is executed when run from the command line """
  
	main()
  
