import logging
import azure.functions as func
import pandas as pd
import snowflake.connector
import json
from sqlalchemy import create_engine
import requests
import concurrent.futures
from requests.structures import CaseInsensitiveDict
from snowflake.connector.pandas_tools import write_pandas, pd_writer
from datetime import datetime
from fastparquet import ParquetFile
from azure.keyvault.secrets import SecretClient
from azure.identity import AzureCliCredential, ManagedIdentityCredential
from pandas import json_normalize
import os
import sys
import numpy as np
import asyncio
from concurrent.futures import ThreadPoolExecutor, as_completed, wait
import httpx
from itertools import chain
from multiprocessing import Pool
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, To, Cc, Bcc
import base64
from snowflake.connector import connect, DictCursor
import shutil
from zenpy import Zenpy
import time
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
import urllib.parse

# Retrieve the Key Vault name from environment variables
keyVaultName = os.environ["AzureAppKeyVaultName"]

# Construct the URI for the Key Vault
KVUri = f"https://{keyVaultName}.vault.azure.net"

# Retrieve the current environment stage name
current_env = os.environ["StageName"]

# Check the current environment and set credentials and schema variable accordingly
if current_env == "local":
    # Use Azure CLI credentials for local development environment
    credential = AzureCliCredential()
    # Set the schema variable to 'DEV' for the local environment
    schemavar = "DEV"
elif current_env == "DEVELOPMENT":
    # Use Managed Identity credentials for the development environment
    credential = ManagedIdentityCredential()
    # Set the schema variable to 'PRD' for the development environment
    schemavar = "PRD"
elif current_env == "BI":
    # Use Managed Identity credentials for the BI environment
    credential = ManagedIdentityCredential()
    # Set the schema variable to 'PRD' for the BI environment
    schemavar = "PRD"

# Create a client to interact with Azure Key Vault using the specified URL and credentials
client = SecretClient(vault_url=KVUri, credential=credential)

# def df_to_snowflake(data, tablename, schemavar=schemavar):
#     if not isinstance(data, (pd.DataFrame, list)):
#         raise ValueError(f"Expected a DataFrame or list but received {type(data)}")
#     if isinstance(data, list):
#         data = pd.DataFrame(data)
#     if current_env == "local":
#         python_snowflake_uname = client.get_secret("python-env-sf-uname")
#         python_snowflake_pass = client.get_secret("python-env-sf-password")
#     else:
#         python_snowflake_uname = client.get_secret("python-snowflake-uname")
#         python_snowflake_pass = client.get_secret("python-snowflake-pass")
#     account_identifier = 'wz65202.east-us-2.azure'
#     user = python_snowflake_uname.value
#     password = python_snowflake_pass.value
#     database_name = 'ZENDESK'
#     schema_name = schemavar
#     conn_string = f"snowflake://{user}:{password}@{account_identifier}/{database_name}/{schema_name}"
#     engine = create_engine(conn_string, connect_args={'charset': 'utf8'})
#     connection = engine.connect()
#     try:
#         data.columns = [column.upper() for column in data.columns]
#         new_columns = []
#         col_counts = {}
#         for col in data.columns:
#             if col in col_counts:
#                 col_counts[col] += 1
#                 new_col = f"{col}_{col_counts[col]}"
#             else:
#                 col_counts[col] = 0
#                 new_col = col
#             new_columns.append(new_col)
#         data.columns = new_columns
#         data.to_sql(tablename, con=engine, index=False, if_exists='replace', method=pd_writer, chunksize=10000)
#         logging.info("Data inserted successfully into Snowflake!")
#     except Exception as e:
#         logging.info("Error:", e)
#         exc_type, exc_obj, exc_tb = sys.exc_info()
#         fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
#         logging.info(exc_type)
#         logging.info(fname)
#         logging.info(exc_tb.tb_lineno)
#     finally:
#         connection.close()

# Function to load data into a Snowflake table
def df_to_snowflake(data, tablename, schemavar=schemavar):
    # Ensure the data is either a pandas DataFrame or a list
    if not isinstance(data, (pd.DataFrame, list)):
        raise ValueError(f"Expected a DataFrame or list but received {type(data)}")
    
    # If data is a list, convert it to a DataFrame
    if isinstance(data, list):
        data = pd.DataFrame(data)
    
    # Retrieve Snowflake credentials based on the environment
    if current_env == "local":
        # For local environment, fetch username and password from Azure Key Vault secrets for development
        python_snowflake_uname = client.get_secret("python-env-sf-uname")
        python_snowflake_pass = client.get_secret("python-env-sf-password")
    else:
        # For non-local environments, fetch production Snowflake credentials
        python_snowflake_uname = client.get_secret("python-snowflake-uname")
        python_snowflake_pass = client.get_secret("python-snowflake-pass")

    # Set up Snowflake connection details
    account_identifier = 'wz65202.east-us-2.azure'
    user = python_snowflake_uname.value
    password = python_snowflake_pass.value
    database_name = 'ZENDESK'
    schema_name = schemavar
    conn_string = f"snowflake://{user}:{password}@{account_identifier}/{database_name}/{schema_name}"

    # Create a SQL Alchemy engine for the Snowflake connection
    engine = create_engine(conn_string, connect_args={'charset': 'utf8'})
    connection = engine.connect()

    try:
        # Convert DataFrame column names to uppercase
        data.columns = [column.upper() for column in data.columns]

        # Resolve column name duplicates by appending a count suffix
        new_columns = []
        col_counts = {}
        for col in data.columns:
            if col in col_counts:
                col_counts[col] += 1
                new_col = f"{col}_{col_counts[col]}"
            else:
                col_counts[col] = 0
                new_col = col
            new_columns.append(new_col)
        data.columns = new_columns

        # Load the DataFrame into the Snowflake table
        data.to_sql(tablename, con=engine, index=False, if_exists='replace', method=pd_writer, chunksize=10000)
        logging.info("Data inserted successfully into Snowflake!")
    except Exception as e:
        # Handle exceptions and logging.info error details including file name and line number
        logging.error("Error:", e)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        logging.error(exc_type)
        logging.error(fname)
        logging.error(exc_tb.tb_lineno)
    finally:
        # Close the database connection
        connection.close()


# Function to fetch tickets from Zendesk after a specified date
def fetch_tickets_after_date(subdomain, email, token, start_date, max_workers=5):
    # Set up credentials for Zendesk API
    creds = {
        'email': email,
        'token': token,
        'subdomain': subdomain
    }
    # Initialize Zenpy client with provided credentials
    zendesk = Zenpy(**creds)

    # Function to transform ticket data into a dictionary
    def fetch_ticket_data(ticket):
        # Basic ticket information
        ticket_dict = {
            'Ticket ID': ticket.id,
            'Subject': ticket.subject,
            'Status': ticket.status,
            'Created At': ticket.created_at,
            'Updated At': ticket.updated_at
        }
        # Adding additional fields from the ticket to the dictionary
        for field in ticket.to_dict():
            if field not in ticket_dict:
                ticket_dict[field] = ticket.to_dict()[field]
        return ticket_dict

    # Retrieve all tickets from Zendesk
    tickets = zendesk.tickets()
    ticket_data = []

    # Use a ThreadPoolExecutor to process tickets concurrently
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Map fetch_ticket_data function to each ticket
        ticket_data = list(executor.map(fetch_ticket_data, tickets))

    # Convert the list of ticket dictionaries to a pandas DataFrame
    df = pd.DataFrame(ticket_data)
    return df

# Function to fetch users from Zendesk
def fetch_users(subdomain, email, token, max_workers=5):
    # Set up credentials for Zendesk API
    creds = {
        'email': email,
        'token': token,
        'subdomain': subdomain
    }
    # Initialize Zenpy client with provided credentials
    zendesk = Zenpy(**creds)

    # Function to transform user data into a dictionary
    def fetch_user_data(user):
        # Basic user information
        user_dict = {
            'User ID': user.id,
            'Name': user.name,
            'Email': user.email,
            'Created At': user.created_at,
            'Updated At': user.updated_at
        }
        # Adding additional fields from the user to the dictionary
        for field in user.to_dict():
            if field not in user_dict:
                user_dict[field] = user.to_dict()[field]
        return user_dict

    # Retrieve all users from Zendesk
    users = zendesk.users()
    user_data = []

    # Use a ThreadPoolExecutor to process users concurrently
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Map fetch_user_data function to each user
        user_data = list(executor.map(fetch_user_data, users))

    # Convert the list of user dictionaries to a pandas DataFrame
    df = pd.DataFrame(user_data)
    return df


#logging.basicConfig(level=logging.INFO)

# Function to fetch groups from Zendesk
def fetch_groups(subdomain, email, token, max_workers=5):
    # Set up credentials for accessing the Zendesk API
    creds = {
        'email': email,         # Zendesk account email
        'token': token,         # API token for authentication
        'subdomain': subdomain  # Zendesk account subdomain
    }

    # Initialize a Zenpy client instance with the provided credentials
    zendesk = Zenpy(**creds)

    # Inner function to process and extract relevant data from a group object
    def fetch_group_data(group):
        # Basic group information structured in a dictionary
        group_dict = {
            'Group ID': group.id,
            'Name': group.name,
            'Created At': group.created_at,
            'Updated At': group.updated_at
        }

        # Iterate over other fields in the group object and add them to the dictionary
        # Fields from the group object are converted to a more readable format
        for field, value in group.to_dict().items():
            readable_field = ' '.join([word.capitalize() for word in field.split('_')])
            # Ensure not to overwrite existing keys
            if readable_field not in group_dict:
                group_dict[readable_field] = value

        return group_dict

    # Retrieve all groups from Zendesk
    groups = zendesk.groups()
    group_data = []

    # Utilize a ThreadPoolExecutor to process multiple groups concurrently
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Map the fetch_group_data function to each group
        group_data = list(executor.map(fetch_group_data, groups))

    # Convert the list of group data dictionaries into a pandas DataFrame
    df = pd.DataFrame(group_data)

    return df


# Function to fetch a page of data from a given URL
def fetch_page(url, headers):
    # Send a GET request to the specified URL with the given headers
    response = requests.get(url, headers=headers)
    # Check if the response status code is 200 (OK)
    if response.status_code == 200:
        # Return the JSON content of the response
        return response.json()
    else:
        # If the response status code is not 200, logging.info an error message
        logging.error(f"Failed to fetch data: {response.status_code}")
        return None

# Function to fetch all ticket metrics from Zendesk
def fetch_all_ticket_metrics(subdomain, email, token, max_workers=10):
    # Prepare the credentials for Basic Authentication
    credentials = f'{email}/token:{token}'
    # Encode the credentials using base64
    encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')

    # Set up the headers for the HTTP request
    headers = {
        'Accept': 'application/json',
        'Authorization': f'Basic {encoded_credentials}',
    }

    # Construct the initial URL to fetch ticket metrics from Zendesk
    initial_url = f"https://{subdomain}.zendesk.com/api/v2/ticket_metrics"
    urls_to_fetch = [initial_url]
    all_metric_data = []

    # Use a ThreadPoolExecutor to manage concurrent requests
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Create a mapping of future objects to URLs
        future_to_url = {executor.submit(fetch_page, url, headers): url for url in urls_to_fetch}
        
        # Loop until there are no more futures in the mapping
        while future_to_url:
            for future in as_completed(future_to_url):
                url = future_to_url[future]
                try:
                    # Get the result of the future object (the response data)
                    data = future.result()
                    if data:
                        # Append the ticket metrics to the all_metric_data list
                        all_metric_data.extend(data['ticket_metrics'])
                        # Check if there's a next page and if so, submit a new request for it
                        next_page = data.get('next_page')
                        if next_page:
                            future_to_url[executor.submit(fetch_page, next_page, headers)] = next_page
                except Exception as e:
                    # logging.info an error message if the request fails
                    logging.error(f"Request failed for {url}: {e}")
                # Remove the future from the mapping
                del future_to_url[future]

    # Convert the list of all metric data into a pandas DataFrame
    df = pd.DataFrame(all_metric_data)
    return df

# Function to fetch a page of metric events from a given URL
def fetch_page_metric_events(url, headers):
    # Perform an HTTP GET request to the specified URL with the given headers
    response = requests.get(url, headers=headers)
    # Check if the response status code is 200 (OK)
    if response.status_code == 200:
        # Return the JSON content of the response
        return response.json()
    else:
        # If the response status code is not 200, logging.info an error message
        logging.error(f"Failed to fetch data: {response.status_code}, URL: {url}")
        return None

# Function to fetch all ticket metric events from Zendesk
def fetch_ticket_metric_events(subdomain, email, token, start_time, max_workers):
    # Prepare the credentials for Basic Authentication
    credentials = f'{email}/token:{token}'
    # Encode the credentials using base64
    encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')

    # Set up the headers for the HTTP request
    headers = {
        'Accept': 'application/json',
        'Authorization': f'Basic {encoded_credentials}',
    }

    # Construct the initial URL for the incremental ticket metric events endpoint
    initial_url = f"https://{subdomain}.zendesk.com/api/v2/incremental/ticket_metric_events.json?start_time={start_time}"
    # Fetch the initial page of data
    initial_response = fetch_page_metric_events(initial_url, headers)
    # Return an empty DataFrame if the initial response is None (failed to fetch)
    if not initial_response:
        return pd.DataFrame()  

    # Initialize a list to store all event data
    all_event_data = initial_response['ticket_metric_events']
    # Initialize a list of start times for pagination, starting with the end time from the initial response
    start_times = [initial_response['end_time']]

    # Use a ThreadPoolExecutor to manage concurrent requests
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Dictionary to map futures to their corresponding start times
        future_to_start_time = {}

        # Loop until there are no more start times for pagination
        while start_times:
            # Fetch the next start time and construct the URL for the next page
            new_start_time = start_times.pop(0)
            next_url = f"https://{subdomain}.zendesk.com/api/v2/incremental/ticket_metric_events.json?start_time={new_start_time}"
            # Submit a new fetch task to the executor
            future = executor.submit(fetch_page_metric_events, next_url, headers)
            future_to_start_time[future] = new_start_time

            # Process completed futures
            for future in as_completed(future_to_start_time):
                start_time = future_to_start_time[future]
                data = future.result()
                if data:
                    # Extend the all_event_data list with the new data
                    all_event_data.extend(data['ticket_metric_events'])
                    # If the end_of_stream flag is False, add the end time to start_times for further pagination
                    if not data['end_of_stream']:
                        start_times.append(data['end_time'])
                # Remove the processed future from the mapping
                del future_to_start_time[future]

    # Convert the list of all event data into a pandas DataFrame
    df = pd.DataFrame(all_event_data)
    return df

def send_alert_to_slack(channel, message,slacktoken):
        client = WebClient(token=slacktoken)
        emoji2 = ":fire:"
        try:
            response = client.chat_postMessage(
                channel=channel,
                text=message,
                icon_emoji=emoji2
            )
            logging.info("Message sent successfully!")
        except SlackApiError as e:
            logging.error(f"Error sending message to Slack: {e.response['error']}")
def send_success_to_slack(channel, message,slacktoken):
        client = WebClient(token=slacktoken)
        emoji2 = ":ship:"
        try:
            response = client.chat_postMessage(
                channel=channel,
                text=message,
                icon_emoji=emoji2
            )
            logging.info("Message sent successfully!")
        except SlackApiError as e:
            logging.error(f"Error sending message to Slack: {e.response['error']}")
# Function to fetch search results from a given URL
def fetch_search_results(url, headers):
    # Perform an HTTP GET request to the specified URL with the given headers
    response = requests.get(url, headers=headers)
    # Check if the response status code is 200 (OK)
    if response.status_code == 200:
        # Return the JSON content of the response
        return response.json()
    else:
        # If the response status code is not 200, logging.info an error message
        logging.error(f"Failed to fetch data: {response.status_code}, URL: {url}")
        return None

# Function to perform a search operation in Zendesk
def zendesk_search(email, token, subdomain):
    # Prepare the credentials for Basic Authentication
    credentials = f'{email}/token:{token}'
    # Encode the credentials using base64
    encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')

    # Set up the headers for the HTTP request
    headers = {
        'Accept': 'application/json',
        'Authorization': f'Basic {encoded_credentials}',
    }

    # Define the base search query
    base_query = "status:open status:pending status:solved status:closed"
    
    # Construct the initial URL for the Zendesk Search API endpoint
    # Zendesk Search API endpoint: '/api/v2/search/export'
    base_url = f"https://{subdomain}.zendesk.com/api/v2/search/export?query={base_query}&page[size]=1000&filter[type]=ticket"

    # Initialize a list to store all search results
    all_results = []
    url_to_fetch = base_url

    # Loop to fetch all search results
    while url_to_fetch:
        # Fetch search results from the current URL
        response_data = fetch_search_results(url_to_fetch, headers)
        if response_data:
            # Check if there are no results and no more pages to fetch
            if not response_data['results'] and not response_data['meta']['has_more']:
                break
            # Extend the all_results list with the new results
            all_results.extend(response_data['results'])
            # Update the URL to fetch the next page of results, if available
            url_to_fetch = response_data['links']['next'] if 'next' in response_data['links'] else None

    # Convert the list of all search results into a pandas DataFrame
    df = pd.DataFrame(all_results)
    return df


def query_snowflake_for_ticket_ids():
    if current_env == "local":
        python_snowflake_uname = client.get_secret("python-env-sf-uname")
        python_snowflake_pass = client.get_secret("python-env-sf-password")
    else:
        python_snowflake_uname = client.get_secret("python-snowflake-uname")
        python_snowflake_pass = client.get_secret("python-snowflake-pass")
    account_identifier = 'wz65202.east-us-2.azure'
    user = python_snowflake_uname.value
    password = python_snowflake_pass.value
    database_name = 'ZENDESK'
    schema_name = schemavar
    # Construct the connection string for the Snowflake database
    conn_string = f"snowflake://{user}:{password}@{account_identifier}/{database_name}/{schema_name}"
    # Create a SQL Alchemy engine for connecting to Snowflake
    engine = create_engine(conn_string, connect_args={'charset': 'utf8'})
    # Establish a connection using the engine
    connection = engine.connect()

    # Connect to Snowflake using the native connector
    ctx = snowflake.connector.connect(
        user=user,                 # Snowflake account username
        password=password,         # Snowflake account password
        account=account_identifier,# Snowflake account identifier
        database=database_name,    # Snowflake database name
        schema=schema_name         # Snowflake schema name
    )
    # Create a cursor object to execute queries
    cs = ctx.cursor()

    try:
        # Execute a SQL query to select all IDs from the 'tickets_all' table
        cs.execute("SELECT ID FROM tickets_all")
        # Fetch all the results from the query and store ticket IDs in a list
        ticket_ids = [row[0] for row in cs.fetchall()]
        # Return the list of ticket IDs
        return ticket_ids
    finally:
        # Close the cursor and the connection
        cs.close()
        ctx.close()


# Function to fetch metrics for a specific ticket using Zendesk API
# def fetch_ticket_metrics(ticket_id, headers, subdomain):
#     # Construct the URL for the Zendesk Ticket Metrics API endpoint
#     # Zendesk Ticket Metrics API endpoint: '/api/v2/tickets/{ticket_id}/metrics'
#     url = f"https://{subdomain}.zendesk.com/api/v2/tickets/{ticket_id}/metrics"

#     # Perform an HTTP GET request to the specified URL with the given headers
#     response = requests.get(url, headers=headers)
#     # Check if the response status code is 200 (OK)
#     if response.status_code == 200:
#         # Return the JSON content of the response
#         return response.json()
#     else:
#         # If the response status code is not 200, logging.info an error message
#         logging.info(f"Failed to fetch data for ticket ID {ticket_id}: {response.status_code}")
#         return None
# Function to fetch metrics for a specific ticket using Zendesk API
def fetch_ticket_metrics(ticket_id, headers, subdomain, max_retries=5, backoff_factor=2):
    # Construct the URL for fetching metrics of a specific ticket from the Zendesk API
    url = f"https://{subdomain}.zendesk.com/api/v2/tickets/{ticket_id}/metrics"

    # Initialize the retry counter
    retries = 0

    # Loop to attempt fetching the ticket metrics, with a maximum number of retries
    while retries < max_retries:
        # Perform an HTTP GET request to the specified URL with the provided headers
        response = requests.get(url, headers=headers)

        # Check if the response status code is 200 (OK)
        if response.status_code == 200:
            # If the request is successful, parse and return the JSON content of the response
            return response.json()
        elif response.status_code == 429:
            # If the response indicates rate limiting (status code 429), handle it
            # Determine the wait time, either from the 'Retry-After' header or using exponential backoff
            wait_time = int(response.headers.get("Retry-After", backoff_factor * (2 ** retries)))
            # Log a message indicating that rate limiting has occurred
            logging.info(f"Rate limit hit, retrying after {wait_time} seconds for ticket ID {ticket_id}")
            # Pause execution for the determined wait time
            time.sleep(wait_time)
            # Increment the retry counter
            retries += 1
        else:
            # Log any other kind of failure
            logging.info(f"Attempt {retries + 1} failed: Failed to fetch data for ticket ID {ticket_id}: {response.status_code}")
            # Increment the retry counter and wait for an exponentially increasing time
            retries += 1
            time.sleep(backoff_factor * (2 ** retries))

    # If all retries fail, log a message and return None
    logging.info(f"All retries failed for ticket ID {ticket_id}")
    return None



# Function to fetch metrics for all tickets in a given dataset
def get_ticket_metrics_all(email, token, subdomain, max_workers):
    # Prepare the credentials for Basic Authentication
    credentials = f'{email}/token:{token}'
    # Encode the credentials using base64 for HTTP header usage
    encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')

    # Set up the HTTP request headers with authorization and content type
    headers = {'Authorization': f'Basic {encoded_credentials}', 'Accept': 'application/json'}

    # Obtain a list of ticket IDs from an external source, presumably Snowflake
    ticket_ids = query_snowflake_for_ticket_ids()

    # Initialize an empty list to store all metrics
    all_metrics = []
    # Copy the list of ticket IDs to track those that need to be fetched
    failed_ticket_ids = ticket_ids.copy()

    # Loop to ensure all tickets are processed, including those that initially fail
    while failed_ticket_ids:
        # Use a ThreadPoolExecutor for concurrent requests
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Create a dictionary mapping future objects (asynchronous operations) to ticket IDs
            future_to_id = {executor.submit(fetch_ticket_metrics, tid, headers, subdomain): tid for tid in failed_ticket_ids}
            # Reset the list of failed ticket IDs for the next iteration
            failed_ticket_ids = []

            # Process the futures (asynchronous operations) as they complete
            for future in as_completed(future_to_id):
                ticket_id = future_to_id[future]
                # Obtain the result of the future, which is the response from the fetch_ticket_metrics function
                data = future.result()
                if data:
                    # If data is successfully fetched, append the metrics to the all_metrics list
                    all_metrics.append(data['ticket_metric'])
                else:
                    # If fetching data failed, add the ticket ID to the list for retry
                    failed_ticket_ids.append(ticket_id)

    # Convert the list of all fetched metrics into a pandas DataFrame for further analysis or use
    return pd.DataFrame(all_metrics)


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processing a request.')
    errorlist = []
    try:
        zendesk_table = req.params.get('zendesk_table')
        if not zendesk_table:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                return func.HttpResponse(f"Pass the zendesk table name.")
        zendesk_token_1 = client.get_secret("zendeskapitoken-pss")
        zendesk_token = zendesk_token_1.value
        slacktoken_kv = client.get_secret("slack-bot-az-func-dev")
        slacktoken = slacktoken_kv.value
        start_date = datetime(2022, 10, 18)
        max_workers_count = min(32, os.cpu_count() + 4)
        if str(zendesk_table) == "tickets":
            df = fetch_tickets_after_date('heartlandmyaccount', 'prakharsingh.sengar@e-hps.com', zendesk_token, start_date, max_workers_count)
            df_to_snowflake(df,tablename='tickets') 
        elif str(zendesk_table) == "users":
            user_df = fetch_users('heartlandmyaccount', 'prakharsingh.sengar@e-hps.com', zendesk_token, max_workers_count)
            df_to_snowflake(user_df, tablename='users')
        elif str(zendesk_table) == "groups":
            groups_df = fetch_groups('heartlandmyaccount', 'prakharsingh.sengar@e-hps.com', zendesk_token, max_workers_count)
            df_to_snowflake(groups_df, tablename='groups')
        elif str(zendesk_table) == "ticket_metrics":
            ticket_metrics_df = fetch_all_ticket_metrics('heartlandmyaccount', 'prakharsingh.sengar@e-hps.com', zendesk_token, max_workers_count)
            df_to_snowflake(ticket_metrics_df, tablename='ticket_metrics')
        elif str(zendesk_table) == "ticket_metrics_events":
            #start_time = int(time.time()) - 31560000  
            start_time = int(time.mktime(start_date.timetuple()))
            ticket_metrics_events_df = fetch_ticket_metric_events('heartlandmyaccount', 'prakharsingh.sengar@e-hps.com', zendesk_token, start_time, max_workers_count)
            df_to_snowflake(ticket_metrics_events_df, tablename='ticket_metrics_events')
        elif str(zendesk_table) == "tickets_all":
            tickets_all_df = zendesk_search('prakharsingh.sengar@e-hps.com', zendesk_token,'heartlandmyaccount')
            df_to_snowflake(tickets_all_df, tablename='tickets_all')
        elif str(zendesk_table) == "ticket_metrics_all":
            ticket_metrics_all_df = get_ticket_metrics_all('prakharsingh.sengar@e-hps.com', zendesk_token, 'heartlandmyaccount',max_workers=10)
            df_to_snowflake(ticket_metrics_all_df, tablename='ticket_metrics_all')
    except Exception as e1: 
        errorlist.append(str(e1))
    finally:
        if len(errorlist)==0:
            logging.info("No error")
            channel2 = 'py_zendesk'
            message2 = f'python_zendesk_ingest Az Function ran successfully. Table ZENDESK.{schemavar}.{zendesk_table} is loaded'
            send_success_to_slack(channel2, message2, slacktoken)
        else:
            t1 = "".join(str(element) for element in errorlist)
            channel = 'py_zendesk'
            message = f'Please check python_zendesk_ingest Az Function, Error is: ' + t1 
            send_alert_to_slack(channel, message, slacktoken)
    return func.HttpResponse(f"python_zendesk_ingest Az function executed successfully.", 
                             status_code=200
                             )
